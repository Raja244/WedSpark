/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package weddingplannersystem;

/**
 *
 * @author Raja
 */
public class WeddingPlannerSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //TODO code application logic here
           StartMain main=new StartMain();
           AdminDashboard ad=new AdminDashboard();
           main.setVisible(true);
//           sqlConnection sql=new sqlConnection();
//           sql.getuserDetailsAsTable();
           //sqlConnection sql=new sqlConnection();
           //sql.getuserDetailsAsTable();
    }
    
}
