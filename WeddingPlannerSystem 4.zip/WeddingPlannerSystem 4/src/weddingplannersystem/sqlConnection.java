
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package weddingplannersystem;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.tree.DefaultTreeCellEditor;

/**
 *
 * @author Raja
 */
public class sqlConnection {
    Connection conn=null;
    PreparedStatement ptr=null,ptr1=null,ptr2=null,ptr3=null,ptr4=null;
    ResultSet rs=null;
    int maxSL;
    public void checkConnection(){
    try {
        String url="jdbc:mysql://localhost:3306/wedding_planner_db?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String UName="root";
        String UPass="";
        conn=DriverManager.getConnection(url, UName, UPass);
    }
    catch(SQLException e){
        JOptionPane.showMessageDialog(null, "Connection Faild");
    }
    }
    public void addUser(String userName,String userPassword,String userType){
        try {
            checkConnection();
            if (conn!=null){ 
                String queryCheck="SELECT * FROM user_master WHERE userName=?;";
                ptr=conn.prepareStatement(queryCheck);
                ptr.setString(1, userName);
                rs=ptr.executeQuery();
                 if(rs.next()) {
                    JOptionPane.showMessageDialog(null, "User Allready Exist");
                 }
                 else{
                countRow();
                String query="insert into user_master (UID,userName,userPassword,userType)values(?,?,?,?)";
                String query1="insert into user_details_tb (UID,userName)values(?,?)";
                String query2="insert into user_cattering (userName)values(?)";
                String query3="insert into user_booking_tb (userName)values(?)";
                ptr=conn.prepareStatement(query);
                ptr.setInt(1,(maxSL+1));
                ptr.setString(2, userName);
                ptr.setString(3,userPassword);
                ptr.setString(4,userType);
                ptr.executeUpdate();
                //for user_details_tb save the data
                ptr1=conn.prepareStatement(query1);
                ptr1.setInt(1,(maxSL+1));
                ptr1.setString(2, userName);
                ptr1.executeUpdate();
                ptr2=conn.prepareStatement(query2);
                ptr2.setString(1, userName);
                ptr2.executeUpdate();
                ptr3=conn.prepareStatement(query3);
                ptr3.setString(1, userName);
                ptr3.executeUpdate();
                //ddUserAsGuestTable(userName);
                JOptionPane.showMessageDialog(null, "User Added Succesfully");
                }
            }
        }catch (SQLException ex) {
            //JOptionPane.showMessageDialog(null, "Exception Is There Please Restart The Application");
            System.out.println(ex);
        }
        
    }

    /**
     *
     * @param userName
     * @param userPassword
     */
    public void deleteUser(String userName,String userPassword){
        try {
            checkConnection();
            if (conn!=null){
                String query="SELECT * FROM user_master WHERE userName=? and userPassword=?;";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                ptr.setString(2, userPassword);
                rs=ptr.executeQuery();
                 if(rs.next()) {
                    String Deletequery="DELETE FROM user_master WHERE userName=? and userPassword=?;";
                    String DeleteFromDetailsquery="DELETE FROM user_details_tb WHERE userName= ?;";
                    String DeleteFromCatteringquery="DELETE FROM user_cattering WHERE userName= ?;";
                    String DeleteFromBookingquery="DELETE FROM user_booking_tb WHERE userName= ?;";
                    String DeleteFromGuestquery="DELETE FROM user_guest_tb WHERE userName= ?;";
                    ptr=conn.prepareStatement(Deletequery);
                    ptr.setString(1, userName);
                    ptr.setString(2, userPassword);
                    ptr.executeUpdate();       
                    ptr1=conn.prepareStatement(DeleteFromDetailsquery);
                    ptr1.setString(1, userName);
                    ptr1.executeUpdate();
                    ptr2=conn.prepareStatement(DeleteFromCatteringquery);
                    ptr2.setString(1, userName);
                    ptr2.executeUpdate();
                    ptr3=conn.prepareStatement(DeleteFromBookingquery);
                    ptr3.setString(1, userName);
                    ptr3.executeUpdate();
                    ptr4=conn.prepareStatement(DeleteFromGuestquery);
                    ptr4.setString(1, userName);
                    ptr4.executeUpdate();
                    JOptionPane.showMessageDialog(null, "User "+userName+ " Delete Succesfully");
                 }
                 else{
                     JOptionPane.showMessageDialog(null, "User Password Not Matched");
                 }                                     
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void changePassword(String userName,String userPassword,String newPassword){
        try {
            checkConnection();
            if (conn!=null){
                String query="SELECT * FROM user_master WHERE userName=? and userPassword=?;";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                ptr.setString(2, userPassword);
                rs=ptr.executeQuery();
               
                 if(rs.next()) {
                    
                    String updatePasswordQuery="UPDATE user_master SET userPassword=? WHERE userName=? ; ";
                    ptr=conn.prepareStatement(updatePasswordQuery);
                    ptr.setString(1,newPassword);
                    ptr.setString(2, userName);
                    ptr.executeUpdate();
                    JOptionPane.showMessageDialog(null, "User : "+userName+ " Passsword Updated Succesfully");
                 }
                 else{
                     JOptionPane.showMessageDialog(null, "User Password Not Matched");
                 }             
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
public boolean login(String userName,String userPassword){
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_master WHERE userName=? and userPassword=?;";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                ptr.setString(2, userPassword);
                rs=ptr.executeQuery();
                 if(rs.next()) {
     
                    return true;
                            
                 }
                 else{
                     String queryPassCheck="SELECT * FROM user_master WHERE userName=?;";
                ptr=conn.prepareStatement(queryPassCheck);
                ptr.setString(1, userName);
                //ptr.setString(2, userPassword);
                rs=ptr.executeQuery();
                 if(rs.next()) {
                    JOptionPane.showMessageDialog(null, "Wrong Password");
                 }
                 else{
                    JOptionPane.showMessageDialog(null, "User Not Exist");
                    
                 }
                 }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
        return false;
    }    
    public void userDetails(String userName){
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_master WHERE UName=?;";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                rs=ptr.executeQuery();
                 while(rs.next()) {
                    System.out.print("Name: "+rs.getString("userName")+", ");
                    System.out.print("Salary: "+rs.getString("userName")+", ");;
                    System.out.println();
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void countRow(){
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT count(*) FROM user_master ;";
                ptr=conn.prepareStatement(query);
                rs=ptr.executeQuery();
                while(rs.next()){
            maxSL=Integer.parseInt(rs.getString(1));
            }}
            //System.out.println("Number of records in the cricketers_data table: "+maxSL);   
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void getuserDetailsAsTableUserList(){
        //AdminDashboard tb= new AdminDashboard();
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_master;";
                ptr=conn.prepareStatement(query);
                rs=ptr.executeQuery();
                //countRow();
                DefaultTableModel model =(DefaultTableModel)AdminDashboard.UserListTable.getModel();             
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(2),rs.getString(3),rs.getString(4)});
                }
                //selectUser();                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void getuserDetailsAsTableUserDelete(){
        //AdminDashboard tb= new AdminDashboard();
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_master;";
                ptr=conn.prepareStatement(query);
                rs=ptr.executeQuery();
                //countRow();               
                DefaultTableModel model =(DefaultTableModel)AdminDashboard.UserListTable1.getModel();             
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(2),rs.getString(3),rs.getString(4)});                  
                }
                //selectUser();                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void getuserDetailsAsTableUserUpdate(){
        //AdminDashboard tb= new AdminDashboard();
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_master;";
                ptr=conn.prepareStatement(query);
                rs=ptr.executeQuery();
                //countRow();                
                DefaultTableModel model =(DefaultTableModel)AdminDashboard.UserListTable2.getModel();             
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(2),rs.getString(3),rs.getString(4)});
                }
                //selectUser();                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void selectUser(){
        try {
            AdminDashboard.SeletctUser.removeAllItems();
            AdminDashboard.SeletctUser1.removeAllItems();
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_master;";
                ptr=conn.prepareStatement(query);
                rs=ptr.executeQuery();
                while (rs.next()) {
                    AdminDashboard.SeletctUser.addItem(rs.getString("userName"));
                    AdminDashboard.SeletctUser1.addItem(rs.getString("userName"));
                }                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void updateUserDetails_inDetails_tb(String userName,String GroomFName, String GroomLName, String GroomPhoneNo, String GroomAddress, String BrideFName, String BrideLName, String BridePhoneNo, String BrideAddress){
        try {
            checkConnection();
            if (conn!=null){
                String query="SELECT * FROM user_details_tb WHERE userName=?;";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                rs=ptr.executeQuery();
               
                 if(rs.next()) {                  
                    String addDetailsQuery="UPDATE user_details_tb SET GroomFName=?,GroomLName=?,GroomPhoneNo=?,GroomAddress=?, BrideFName=? ,BrideLName=? ,BridePhoneNo=?,BrideAddress=? WHERE userName=? ; ";
                    ptr=conn.prepareStatement(addDetailsQuery);
                    ptr.setString(1,GroomFName);
                    ptr.setString(2,GroomLName);
                    ptr.setString(3,GroomPhoneNo);
                    ptr.setString(4,GroomAddress);
                    ptr.setString(5,BrideFName);
                    ptr.setString(6,BrideLName);
                    ptr.setString(7,BridePhoneNo);
                    ptr.setString(8,BrideAddress); 
                    ptr.setString(9,userName);
                    ptr.executeUpdate();
                    JOptionPane.showMessageDialog(null, "User : "+userName+ " Details Updated");
                 }
                 else{
                     JOptionPane.showMessageDialog(null, "User Details Not Update");
                 }             
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void setUserDetaisInUserDetails(String userName){
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_details_tb WHERE userName=?;";
                ptr=conn.prepareStatement(query);
                ptr.setString(1,userName);
                rs=ptr.executeQuery();
                if (rs.next()) {
                    UserDashboard.GroomNameInDetails.setText(rs.getString("GroomFName")+" "+rs.getString("GroomLName"));
                    UserDashboard.GroomPhoneNoInDetails.setText(rs.getString("GroomPhoneNo"));
                    UserDashboard.GroomAddressInDetails.setText(rs.getString("GroomAddress"));
                    UserDashboard.BrideNameInDetails.setText(rs.getString("BrideFName")+" "+rs.getString("BrideLName"));
                    UserDashboard.BrideMobileNoInDetails.setText(rs.getString("BridePhoneNo"));
                    UserDashboard.BrideAddressInDetails.setText(rs.getString("BrideAddress"));
                    UserDashboard.GroomName.setText(rs.getString("GroomFName"));
                    UserDashboard.BrideName.setText(rs.getString("BrideFName"));
                }               
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void addGuest_inGuest_tb(String userName,String guestName, String guestAddress){
try {
            checkConnection();
            if (conn!=null){ 
                String queryCheck="SELECT * FROM user_guest_tb WHERE userName=? and guestName=?;";
                ptr=conn.prepareStatement(queryCheck);
                ptr.setString(1, userName);
                ptr.setString(2, guestName);
                rs=ptr.executeQuery();
                 if(rs.next()) {
                    JOptionPane.showMessageDialog(null, "User You Already Add This Guest");
                 }
                 else{
                String query="insert into user_guest_tb (userName,guestName,guestAddress)values(?,?,?)";
                
                ptr=conn.prepareStatement(query);
                ptr.setString(1,userName);
                ptr.setString(2, guestName);
                ptr.setString(3,guestAddress);
                
                ptr.executeUpdate();
                JOptionPane.showMessageDialog(null, "Guest Added Succesfully");
                }
            }
        }catch (SQLException ex) {
            //JOptionPane.showMessageDialog(null, "Exception Is There Please Restart The Application");
           System.out.println(ex);
        }
    }
    public void DelleteGuest_inGuest_tb(String userName,String guestName, String guestAddress){
try {
            checkConnection();
            if (conn!=null){ 
                String query="DELETE FROM user_guest_tb WHERE userName=? and guestName=? and guestAddress=?;";  
                ptr=conn.prepareStatement(query);
                ptr.setString(1,userName);
                ptr.setString(2, guestName);
                ptr.setString(3,guestAddress);
                ptr.executeUpdate();
                JOptionPane.showMessageDialog(null, "Guest Deleted Succesfully");              
            }
        }catch (SQLException ex) {
            //JOptionPane.showMessageDialog(null, "Exception Is There Please Restart The Application");
           System.out.println(ex);
        }
    }
    
    public void getGuest_asTable(String userName){
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_guest_tb WHERE userName=?;";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                rs=ptr.executeQuery();
                DefaultTableModel model =(DefaultTableModel)UserDashboard.GuestListTable.getModel();             
                model.setRowCount(0);
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(2),rs.getString(3)});
                }                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void addUserAsGuestTable(String userName){
        try {
            checkConnection();
            if (conn!=null){ 
                String query="CREATE TABLE "+userName+"(guestName varchar(30),guestAddress varchar(200));";
                ptr=conn.prepareStatement(query);
                ptr.execute();;                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void addCaterring(String UserName,String Starter,String MainCourse,String Desserts,String Drinks,String Pack){
        try {
            checkConnection();
            if (conn!=null){
                String queryCheck="select * from user_cattering where userName=?;";
                ptr=conn.prepareStatement(queryCheck);
                ptr.setString(1, UserName);
                rs=ptr.executeQuery();
                if(rs.next()) {
                    String queryAdd="Update user_cattering set Starter=?,MainCourse=?,Desserts=?,Drinks=?,Pack=? where userName=?;";
                    ptr=conn.prepareStatement(queryAdd);
                    ptr.setString(1, Starter);
                    ptr.setString(2, MainCourse);
                    ptr.setString(3, Desserts);
                    ptr.setString(4, Drinks);
                    ptr.setString(5, Pack);
                    ptr.setString(6, UserName);
                    ptr.executeUpdate();
                 }        
            }
        }catch (SQLException ex) {
            //JOptionPane.showMessageDialog(null, "Exception Is There Please Restart The Application");
            ex.printStackTrace();
        }
        
    }
    public void AdminMassege(String userName,String message){
        try {
            checkConnection();
                    String updatePasswordQuery="insert into admin_message_tb (userName,message,status)values(?,?,?)";
                    ptr=conn.prepareStatement(updatePasswordQuery);
                    ptr.setString(1,userName);
                    ptr.setString(2, message);
                    ptr.setString(3, "Un-Checked");
                    ptr.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Message Send Succesfully");
        }catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public boolean BookDetailsCheck(String userName){
        try {
            checkConnection();
            if (conn!=null){
                String query="SELECT * FROM user_booking_tb WHERE userName=? ";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                rs=ptr.executeQuery();
                while(rs.next()){
                    if(rs.getString(2)!=null){
                    return false;
                    }else{
                        return true;
                        } 
                }                                 
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "  ");
            System.out.println(ex);
        }
        return true;
    }
        public void AddUserBook(String userName,String marriageDate,String allBook,String bookingCharge){
        try {
            checkConnection();
            if (conn!=null){
                String query="SELECT * FROM user_booking_tb WHERE userName=?;";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                rs=ptr.executeQuery();
               
                 if(rs.next()) {
                    
                    String update="Update user_booking_tb set marriageDate=?,allBook=?,bookingCharge=?,status=? where userName=?";
                    ptr=conn.prepareStatement(update);
                    ptr.setString(1,marriageDate);
                    ptr.setString(2, allBook);
                    ptr.setString(3, bookingCharge);
                    ptr.setString(4, "Pending");
                    ptr.setString(5, userName);
                    ptr.executeUpdate();
                    
                 }
                 else{
                     JOptionPane.showMessageDialog(null, "User Not Exist");
                 }             
            }
        } catch (SQLException ex) {
           // JOptionPane.showMessageDialog(null, "Error");
            System.out.println(ex);
        }
        
    }
    public void setGuest(String userName,int guestNo){
        try {
            checkConnection();
            if (conn!=null){
                String query="SELECT * FROM user_details_tb WHERE userName=?";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                rs=ptr.executeQuery();
               
                 if(rs.next()) {
                    
                    String updatePasswordQuery="Update user_details_tb set guestNumber=? where userName=?";
                    ptr=conn.prepareStatement(updatePasswordQuery);
                    ptr.setInt(1,guestNo);
                    ptr.setString(2, userName);
                    ptr.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Add SuccesFully");
                 }
                 else{
                     JOptionPane.showMessageDialog(null, "User Not Exist");
                 }             
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    public void getEventList(){
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_booking_tb;";
                ptr=conn.prepareStatement(query);
                rs=ptr.executeQuery();
                DefaultTableModel model =(DefaultTableModel)EventManager.EventTable.getModel();
                
                model.setRowCount(0);
                
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
                    
                }                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
        public void setStatus(String userName,String status){
        try {
            checkConnection();
            if (conn!=null){
                String query="SELECT * FROM user_booking_tb WHERE userName=?";
                ptr=conn.prepareStatement(query);
                ptr.setString(1, userName);
                rs=ptr.executeQuery();
               
                 if(rs.next()) {
                    
                    String updatePasswordQuery="Update user_booking_tb set status=? where userName=?";
                    ptr=conn.prepareStatement(updatePasswordQuery);
                    ptr.setString(1,status);
                    ptr.setString(2, userName);
                    ptr.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Update Succefully");
                 }
                 else{
                     JOptionPane.showMessageDialog(null, "User Not Exist");
                 }             
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
 public void getEventListinAdmin(){
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_booking_tb;";
                ptr=conn.prepareStatement(query);
                rs=ptr.executeQuery();
                DefaultTableModel model =(DefaultTableModel)AdminDashboard.EventTable.getModel();
                
                model.setRowCount(0);
                
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
                    
                }                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
 public void getNotificationInAdmin(){
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM admin_message_tb;";
                ptr=conn.prepareStatement(query);
                rs=ptr.executeQuery();
                DefaultTableModel model =(DefaultTableModel)AdminDashboard.NotificationTable.getModel();
                model.setRowCount(0); 
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3)});   
                }                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
        
    }
 public void UpdateAdminMassege(String userName,String message){
        try {
            checkConnection();
                    String updatePasswordQuery="UPDATE admin_message_tb SET status=? WHERE userName=? AND message=? ;";
                    ptr=conn.prepareStatement(updatePasswordQuery);
                    ptr.setString(1,"Checked");
                    ptr.setString(2, userName);
                    ptr.setString(3, message);
                    ptr.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Checked Succesfully");
        }catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
 public void getCateringInAdmin(){
        try {
            checkConnection();
            if (conn!=null){               
                String query="SELECT * FROM user_cattering;";
                ptr=conn.prepareStatement(query);
                rs=ptr.executeQuery();
                DefaultTableModel model =(DefaultTableModel)AdminDashboard.CateringTable.getModel();
                model.setRowCount(0); 
                while (rs.next()) {
                    model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)});   
                }                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error");
        }
        
    }
}
